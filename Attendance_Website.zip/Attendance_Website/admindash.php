<?php
session_start();

// Check if the user is logged in and has the roleID of 1 (Admin)
if (!isset($_SESSION['userID']) || $_SESSION['roleID'] != 1) {
    // If not logged in or not an admin, redirect to login page
    header("Location: login.php");
    exit();
}

// If the user is an admin, display the admin page content
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Link to external CSS file -->
    <link rel="stylesheet" href="index.css">
</head>
<body>

<header>
    <h1>Admin Dashboard</h1>
</header>

<div class="container">
    <p>You are logged in as an admin. Below are the administrative options.</p>

    <!-- Admin-specific content -->
    <div class="dashboard-section">
        <h2>Admin Overview</h2>
        <p>From here, you can manage users, view reports, or perform other administrative tasks.</p>
    </div>

    <div class="dashboard-section">
        <h3>Manage Users</h3>
        <p>
            <a href="add_user.php">Add New User</a> | 
            <a href="edit_user.php">Edit User Details</a> | 
            <a href="search_user.php">Search User</a>
        </p>
    </div>

    <div class="dashboard-section">
        <h3>Reports</h3>
        <p>
            <a href="view_reports.php">View Reports</a> | 
            <a href="print_reports.php">Print Reports</a>
        </p>
    </div>

    <div class="dashboard-section">
        <h3>Permissions</h3>
        <p>
            <a href="accept_permission.php">Accept Permission</a> | 
            <a href="decline_permission.php">Decline Permission</a>
        </p>
    </div>

    <!-- Option to log out -->
    <a href="logout.php" class="logout-link">Log Out</a>
</div>

</body>
</html>
