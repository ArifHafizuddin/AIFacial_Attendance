import cv2
import face_recognition
import os
import mysql.connector
import numpy as np
from datetime import datetime
from config import connect_db

# Directory to store student face images
STUDENT_FACES_DIR = "student_faces"

# Database connection setup
conn = connect_db()
cursor = conn.cursor()

# Load student face encodings
known_face_encodings = []
known_face_names = []

# Loop through each student's face images and encode them
for student_folder in os.listdir(STUDENT_FACES_DIR):
    student_path = os.path.join(STUDENT_FACES_DIR, student_folder)
    if os.path.isdir(student_path):
        for image_file in os.listdir(student_path):
            image_path = os.path.join(student_path, image_file)
            image = face_recognition.load_image_file(image_path)
            encoding = face_recognition.face_encodings(image)
            if encoding:
                known_face_encodings.append(encoding[0])
                known_face_names.append(student_folder)

print(f"✅ Loaded {len(known_face_names)} students.")

# Function to mark attendance
def mark_attendance(student_id, name):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Check if attendance is already marked for today
    cursor.execute("SELECT * FROM attendance WHERE student_id = %s AND DATE(timestamp) = CURDATE()", (student_id,))
    result = cursor.fetchone()
    
    if not result:
        cursor.execute("INSERT INTO attendance (student_id, name) VALUES (%s, %s)", (student_id, name))
        conn.commit()
        print(f"✅ Attendance marked for {name} (ID: {student_id})")
    else:
        print(f"⚠️ {name} (ID: {student_id}) already marked attendance today.")

# Initialize the webcam
cap = cv2.VideoCapture(0)
print("\n📸 Face Recognition Running... Press 'Q' to Quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        print("❌ Camera error.")
        break

    # Convert frame to RGB (required by face_recognition)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    # Detect face locations and encodings
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    # Process each detected face
    for face_encoding, face_location in zip(face_encodings, face_locations):
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.45)
        name = "Unknown"

        # If a match is found
        if True in matches:
            matched_index = matches.index(True)
            name_id = known_face_names[matched_index]
            name, student_id = name_id.rsplit("_", 1)  # Split to get name and student ID

            # Mark attendance
            mark_attendance(student_id, name)

            # Draw rectangle around face and display message
            top, right, bottom, left = face_location
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, "CAPTURED! You may proceed to class", (left, bottom + 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    # Display the frame with face recognition results
    cv2.imshow("Face Recognition", frame)

    # Exit loop when 'Q' is pressed
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

# Release the webcam and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()

# Close database connection
conn.close()
