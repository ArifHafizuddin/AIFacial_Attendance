<?php
// Include the database connection
include('db.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form inputs
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $roleID = $_POST['role'];
    $imageData = isset($_POST['imageData']) ? $_POST['imageData'] : null; // Ensure imageData is set

    // Check if email already exists
    $sqlCheckEmail = "SELECT * FROM Users WHERE email = '$email'";
    $result = $conn->query($sqlCheckEmail);

    if ($result->num_rows > 0) {
        echo "Error: This email is already registered.<br>";
    } else {
        // Hash the password for security
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Insert user into the Users table
        $sql = "INSERT INTO Users (fullName, email, passwordHash, roleID) 
                VALUES ('$fullName', '$email', '$passwordHash', '$roleID')";

        if ($conn->query($sql) === TRUE) {
            echo "User added successfully!<br>";

            // Get the last inserted userID from the Users table
            $userID = $conn->insert_id;

            // Handle multiple image uploads
            $imageDataArray = $_POST['imageData'];  // Expecting an array of base64 images
            $targetDir = "uploads/";

            // Loop through each captured image and save them
            $imagePaths = [];
            foreach ($imageDataArray as $index => $imageData) {
                // Decode the base64 image and save it to the server
                $imageData = str_replace('data:image/png;base64,', '', $imageData);
                $imageData = base64_decode($imageData);

                // Create unique image names
                $imageName = "user_" . $userID . "_img" . ($index + 1) . ".png";
                $targetFile = $targetDir . $imageName;

                if (file_put_contents($targetFile, $imageData)) {
                    $imagePaths[] = $targetFile;
                } else {
                    echo "Error saving image $index.<br>";
                }
            }

            // Insert the image paths into the face_data table using the same userID
            foreach ($imagePaths as $path) {
                $sqlFaceData = "INSERT INTO face_data (studentID, faceImagePath) 
                                VALUES ('$userID', '$path')";
                if ($conn->query($sqlFaceData) !== TRUE) {
                    echo "Error: " . $sqlFaceData . "<br>" . $conn->error;
                }
            }

            echo "Face data added successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
</head>
<body>
    <h2>Add New User</h2>

    <!-- User addition form -->
    <form action="add_user.php" method="POST" enctype="multipart/form-data">
        <label for="fullName">Full Name:</label>
        <input type="text" id="fullName" name="fullName" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <label for="role">Role:</label>
        <select id="role" name="role" required>
            <option value="1">Admin</option>
            <option value="2">Student</option>
            <option value="3">Lecturer</option>
            <option value="4">Group Coordinator</option>
        </select><br><br>

        <!-- Webcam capture section -->
        <label for="image">Capture Image:</label><br>
        <video id="video" width="320" height="240" autoplay></video><br><br>
        <canvas id="canvas" style="display:none;"></canvas><br>
        <button type="button" id="capture">Capture Image</button><br><br>

        <div id="capturedImagesContainer"></div>

        <!-- Hidden field to store captured images as base64 -->
        <input type="hidden" id="imageData" name="imageData[]"> <!-- Array for base64 images -->
        <input type="submit" value="Add User">
    </form>

    <script>
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const captureButton = document.getElementById('capture');
        const imageDataInput = document.getElementById('imageData');
        const capturedImagesContainer = document.getElementById('capturedImagesContainer');

        let capturedImages = [];

        // Initialize the webcam
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then((stream) => {
                    video.srcObject = stream;
                })
                .catch((error) => {
                    console.log('Error accessing the webcam: ', error);
                });
        }

        // Capture the image
        captureButton.addEventListener('click', () => {
            // Draw the video frame onto the canvas
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);

            // Convert the canvas to base64
            const imageData = canvas.toDataURL('image/png');
            capturedImages.push(imageData);

            // Display the captured images
            const imgElement = document.createElement('img');
            imgElement.src = imageData;
            capturedImagesContainer.appendChild(imgElement);

            // Update the hidden field with the array of captured images
            imageDataInput.value = JSON.stringify(capturedImages);

            // If we have at least 5 images, disable the capture button
            if (capturedImages.length >= 5) {
                captureButton.disabled = true;
                alert("You have captured enough images!");
            }
        });
    </script>
</body>
</html>

