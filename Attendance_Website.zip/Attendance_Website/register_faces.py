import os
import mysql.connector
from flask import Flask, request, jsonify, render_template
import cv2
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Define the directory for student faces
STUDENT_FACES_DIR = "face_data"
os.makedirs(STUDENT_FACES_DIR, exist_ok=True)

# Allowed file extensions for face images
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def connect_db():
    """Connect to the XAMPP MySQL database."""
    try:
        conn = mysql.connector.connect(
            host="localhost",  # XAMPP MySQL is hosted locally
            user="root",       # Default user
            password="",       # Default password is empty
            database="attendance_database"  # Ensure this is the correct database name
        )
        return conn
    except mysql.connector.Error as err:
        print(f"❌ Database connection failed: {err}")
        return None

def allowed_file(filename):
    """Check if the file has a valid extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def check_camera():
    """Check and open the camera."""
    try:
        cap = cv2.VideoCapture(0)  # 0 is usually the default webcam
        if not cap.isOpened():
            raise Exception("Camera not accessible.")
        return cap
    except Exception as e:
        print(f"❌ Camera error: {e}")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register_face', methods=['POST'])
def register_face():
    student_id = request.form.get('student_id')
    name = request.form.get('name')
    email = request.form.get('email')
    password = request.form.get('password')
    role = request.form.get('role')

    if not student_id or not name or not email or not password or not role:
        return jsonify({"error": "All fields are required"}), 400

    # Format the student's folder name and ensure the folder exists
    formatted_name = f"{name}_{student_id}".replace(" ", "_")
    student_folder = os.path.join(STUDENT_FACES_DIR, formatted_name)
    os.makedirs(student_folder, exist_ok=True)

    # Connect to the database
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500

    cursor = conn.cursor()

    # Insert student into the database (check for existing ID)
    try:
        cursor.execute("INSERT INTO students (student_id, name, email, password, role) VALUES (%s, %s, %s, %s, %s)", 
                       (student_id, name, email, password, role))
        conn.commit()
        print(f"✅ Student {name} (ID: {student_id}) added successfully.")
    except mysql.connector.Error as err:
        print(f"❌ MySQL Error: {err}")
        conn.rollback()  # Rollback in case of an error
        return jsonify({"error": f"Error inserting data: {err}"}), 500
    finally:
        cursor.close()
        conn.close()

    # Capture face images using the webcam
    cap = check_camera()
    if not cap:
        return jsonify({"error": "Camera error"})

    face_count = 0
    while face_count < 5:  # Capture 5 images for training
        ret, frame = cap.read()
        if not ret:
            break

        # Save the captured image
        face_image_path = os.path.join(student_folder, f"face_{face_count+1}.jpg")
        cv2.imwrite(face_image_path, frame)
        face_count += 1

    cap.release()

    return jsonify({"success": True, "message": "Student and face images registered successfully!"})

if __name__ == '__main__':
    app.run(debug=True)
