<?php
session_start();
require 'C:\Users\Acer\Desktop\Xampp\htdocs\Attendance_Website\db.php'; // Ensure this file contains a valid PDO connection

// Ensure that the admin is logged in and has the correct role
if (!isset($_SESSION['adminID']) || $_SESSION['roleID'] != 1) {
    header("Location: login.php");
    exit();
}

// Validate and sanitize userID from URL
if (!isset($_GET['userID']) || !is_numeric($_GET['userID'])) {
    die("Invalid User ID.");
}

$userID = (int) $_GET['userID']; // Ensure it's an integer

// Fetch existing user data
try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE userID = :userID");
    $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("User not found.");
    }

    $fullName = $user['fullName'];
    $email = $user['email'];
    $roleID = $user['roleID'];
} catch (PDOException $e) {
    die("Error fetching user: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $fullName = trim($_POST['fullName']);
    $email = trim($_POST['email']);
    
    // Prevent any changes to the roleID and always set it to 1
    $roleID = 1; // Admin can only have roleID 1 (ensure it's not modifiable by the form)

    // Check if the inputs are valid
    if (empty($fullName) || empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Please provide valid inputs.";
    } else {
        try {
            $sql = "UPDATE users SET fullName = :fullName, email = :email WHERE userID = :userID";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':fullName', $fullName);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);

            if ($stmt->execute()) {
                $successMessage = "User details updated successfully!";
            } else {
                $errorMessage = "Error updating user.";
            }
        } catch (PDOException $e) {
            $errorMessage = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Edit User</h2>

        <?php
        // Display any error or success messages
        if (isset($errorMessage)) {
            echo "<p class='error'>$errorMessage</p>";
        }
        if (isset($successMessage)) {
            echo "<p class='success'>$successMessage</p>";
        }
        ?>

        <form method="POST">
            <label>Full Name:</label>
            <input type="text" name="fullName" value="<?php echo htmlspecialchars($fullName); ?>" required><br>

            <label>Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required><br>

            <!-- Role ID is hidden and cannot be changed -->
            <input type="hidden" name="roleID" value="1">

            <button type="submit">Update User</button>
        </form>

        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
