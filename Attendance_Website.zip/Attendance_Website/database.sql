CREATE TABLE Roles (
    roleID INT PRIMARY KEY AUTO_INCREMENT,
    roleName ENUM('Admin', 'Student', 'Lecturer', 'Group Coordinator') NOT NULL
);

CREATE TABLE Users (
    userID INT PRIMARY KEY AUTO_INCREMENT,
    fullName VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    passwordHash VARCHAR(255) NOT NULL,
    roleID INT NOT NULL,
    registeredByAdminID INT,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (roleID) REFERENCES Roles(roleID) ON DELETE CASCADE,
    FOREIGN KEY (registeredByAdminID) REFERENCES Users(userID) ON DELETE SET NULL
);

CREATE TABLE Classes (
    classID INT PRIMARY KEY AUTO_INCREMENT,
    className VARCHAR(255) NOT NULL,
    lecturerID INT NOT NULL,
    FOREIGN KEY (lecturerID) REFERENCES Users(userID) ON DELETE CASCADE
);

CREATE TABLE Attendance (
    attendanceID INT PRIMARY KEY AUTO_INCREMENT,
    studentID INT NOT NULL,
    classID INT NOT NULL,
    scanTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Present', 'Absent', 'Late') NOT NULL,
    FOREIGN KEY (studentID) REFERENCES Users(userID) ON DELETE CASCADE,
    FOREIGN KEY (classID) REFERENCES Classes(classID) ON DELETE CASCADE
);

CREATE TABLE Face_Data (
    faceID INT PRIMARY KEY AUTO_INCREMENT,
    studentID INT NOT NULL,
    faceEmbedding BLOB NOT NULL,
    faceImagePath VARCHAR(255) NOT NULL,
    registeredAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (studentID) REFERENCES Users(userID) ON DELETE CASCADE
);

CREATE TABLE Permission_Letters (
    letterID INT PRIMARY KEY AUTO_INCREMENT,
    studentID INT NOT NULL,
    coordinatorID INT NOT NULL,
    reason TEXT NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (studentID) REFERENCES Users(userID) ON DELETE CASCADE,
    FOREIGN KEY (coordinatorID) REFERENCES Users(userID) ON DELETE CASCADE
);

CREATE TABLE Notifications (
    notificationID INT PRIMARY KEY AUTO_INCREMENT,
    userID INT NOT NULL,
    message TEXT NOT NULL,
    status ENUM('Unread', 'Read') DEFAULT 'Unread',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES Users(userID) ON DELETE CASCADE
);

CREATE TABLE Audit_Log (
    logID INT PRIMARY KEY AUTO_INCREMENT,
    adminID INT NOT NULL,
    action VARCHAR(255) NOT NULL,
    targetUserID INT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (adminID) REFERENCES Users(userID) ON DELETE CASCADE
);

CREATE TABLE Face_Update_Requests (
    requestID INT PRIMARY KEY AUTO_INCREMENT,
    studentID INT NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    requestedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approvedBy INT NULL,
    FOREIGN KEY (studentID) REFERENCES Users(userID) ON DELETE CASCADE,
    FOREIGN KEY (approvedBy) REFERENCES Users(userID) ON DELETE SET NULL
);

CREATE TABLE Class_Schedule (
    scheduleID INT PRIMARY KEY AUTO_INCREMENT,
    classID INT NOT NULL,
    roomNumber VARCHAR(50),
    scheduledDate DATE NOT NULL,
    startTime TIME NOT NULL,
    endTime TIME NOT NULL,
    FOREIGN KEY (classID) REFERENCES Classes(classID) ON DELETE CASCADE
);

CREATE VIEW Attendance_Summary AS
SELECT 
    studentID, 
    COUNT(CASE WHEN status = 'Present' THEN 1 END) AS totalPresent,
    COUNT(CASE WHEN status = 'Late' THEN 1 END) AS totalLate,
    COUNT(CASE WHEN status = 'Absent' THEN 1 END) AS totalAbsent,
    (COUNT(CASE WHEN status = 'Present' THEN 1 END) / COUNT(*)) * 100 AS attendancePercentage
FROM Attendance
GROUP BY studentID;
